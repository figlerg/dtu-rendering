#ifndef MY_GLUT_H
#define MY_GLUT_H

#if defined(__APPLE__) && defined(__MACH__)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#endif
